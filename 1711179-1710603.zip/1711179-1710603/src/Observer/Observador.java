package Observer;

public interface Observador {
    public void notify(String mensagem,Observado o);
}
