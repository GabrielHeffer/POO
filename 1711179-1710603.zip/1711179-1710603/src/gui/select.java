package gui;
import gui.Peca;

public class select {
    public static Peca peca_selecionada;
}
